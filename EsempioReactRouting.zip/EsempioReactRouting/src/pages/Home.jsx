import React from 'react';

function Home() {
  return <h1>Benvenuto nella Home</h1>;
}

export default Home;