import React from 'react';

function About() {
  return <h1>Chi siamo</h1>;
}

export default About;