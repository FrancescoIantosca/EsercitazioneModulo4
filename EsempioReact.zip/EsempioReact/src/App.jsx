import { useState, useEffect, useReducer, useContext } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import NavBar from './assets/component/NavBar'
import Card from './assets/component/Card'
import CardForm from './assets/component/CardForm'
import Form from './assets/component/Form'
import Example from './assets/component/Example'
import Example1 from './assets/component/Example1'
import { ProvaContext } from './assets/store/ProvaContext'

function handleChange(e){
  console.log(e.target.value);
  e.preventDefault(); // Prevenire aggiornamento della pagina
}

function formReducer(state, action){
  switch(action.type){
    case "CHANGE_FIELD":
      return {...state, [action.field]: action.value}

      case "RESET_FORM":
        return {name: "", email: ""}

      default:
        return state;
  }
}

function App() {
  const [count, setCount] = useState(0);
  const [name, setName] = useState("Ciro");
  const [array, setArray] = useState([1, 2, 3]);
  const [data, setData] = useState([]);

  const [formState, dispatchFormState] = useReducer(formReducer, {name: "", email: ""});

  const aggiungiArray = () => {
    const nuovoNumero = 4;
    setArray([...array, nuovoNumero]);
    console.log(array);
  }

      // useReducer
        const handleFieldChange = (field, value) => {
        dispatchFormState({type: "CHANGE_FIELD", field, value})
      }

      const resetForm = () => {
        dispatchFormState({type: "RESET_FORM"})
      }

      const sendForm = (e) => {
        e.preventDefault();
        console.log(formState);
      }

   useEffect(() => {
          // Chiamata HTTP tramite useEffect
          fetch("https://jsonplaceholder.typicode.com/posts")
          .then((response) => response.json())
          .then((data) => {
              setData(data);
              console.log(data);
          });
  
      }, [count]);

  const addGatti = (gatt) => {
    setGatti([...gatti, gatt])
  }
  
  const [gatti, setGatti] = useState ([
    {
    id : 0,
    title : "Alfredo",
    desc : "Micio bello che è bello",
    imgURL : "./gatto.jpg",
    isVisited : true,
    },
    {
    id : 1,
    title : "Ambrogio",
    desc : "Micio pigro dormiglione",
    imgURL : "./gatto.jpg",
    isVisited : false, 
    },
  ]);

  return (
    <ProvaContext.Provider value ={{count, setCount}}>
    <NavBar></NavBar>

    <div style={{display: "flex", gap: "20px", marginBottom: "2%"}}>
      <Card 
      isVisited={true}
        title = "Gatto 1" 
        desc = "Lorem ipsum dolor sit amet consectetur, adipisicing elit." 
        imgURL ="/gatto.jpg">
          è proprio un gatto bello
      </Card>
      <Card 
      isVisited={false}
        title = "Gatto 2" 
        desc = "Lorem adipisicing elit." 
        imgURL ="/gatto.jpg">
          lui è proprio un gatto pigro
      </Card>
    </div>

    <div style={{display: "flex", gap: "20px", marginBottom: "2%"}}>
    {gatti.map((gatto) => (
      <Card
      key = {gatto.id}
      isVisited={gatto.isVisited}
        title = {gatto.title} 
        desc = {gatto.desc} 
        imgURL = {gatto.imgURL}>
      </Card>
    ))}
    </div>

    <div style={{display: "flex", gap: "20px", marginBottom: "2%"}}>
    {gatti
      .filter((gatto) => gatto.isVisited)
      .map((gatto) => (
      <Card
      key = {gatto.id}
      isVisited={gatto.isVisited}
        title = {gatto.title} 
        desc = {gatto.desc} 
        imgURL = {gatto.imgURL}>
      </Card>
    ))}
    </div>


     <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <button onClick={() => alert ("ciao")}>
          alert
        </button>
        <input type="text" onChange={handleChange} />

        <br></br>
        <br></br>

        <button onClick={() => setName((name) => name = "Francesco")}>
          il nome ora è {name}
        </button>

        <button onClick={aggiungiArray}>
          Aggiungi Valore
        </button>
      </div>

 <CardForm addGatti={addGatti}></CardForm>


 <Form addGatti={addGatti}></Form>

 <Example></Example>

<p>Uso di useReducer</p>

<form>
  <div>
    <label htmlFor="name">Nome</label>
    <input type="text"
            id = "name"
            name = "name"
            value={formState.name}
            onChange={(e) => handleFieldChange("name", e.target.value)}>
    </input>
  </div>
  <div>
    <label htmlFor="email">Email</label>
    <input type="email"
            id = "email"
            name = "email"
            value={formState.email}
            onChange={(e) => handleFieldChange("email", e.target.value)}>
    </input>
  </div>
  <button onClick={resetForm}>Resetta il form</button>
  <button onClick={sendForm}>Invia</button>
</form>

<p>Uso di Contex API</p>
<Example1></Example1>





<div style={{display: "flex", gap: "20px", marginBottom: "2%", flexDirection: 'column'}}>
    {data.map((item) => (
      <div key={item.id} style={{marginBottom: "2%", backgroundColor: 'green'}}>
        <p style={{color: 'red'}}>userId: {item.userId}</p>
        <p>title: {item.title}</p>
        <p>{item.body}</p>
      </div>
    ))}
    </div>

      <div>
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p>
    </ProvaContext.Provider>
  );
}

export default App
