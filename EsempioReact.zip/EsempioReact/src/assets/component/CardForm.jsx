function CardForm({addGatti}){

    const handleClick = () => {
        const gatto =  {
    id : 2,
    title : "Mastino Napoletano",
    desc : "Gatto tifoso vero",
    imgURL : "/gatto.jpg",
    isVisited : true, 
    };
        addGatti(gatto);
    }

    return(
        <div>
            <input type="text"></input>
            <input type="text"></input>
            <input type="text"></input>
            <button onClick={handleClick}>Aggiungi card</button>
        </div>
    );
}

export default CardForm;