import './Card.css'
import useCounterProva from '../hooks/useCounterProva';

// Questa Card è HardCodata, ovvero le informazioni sono scritte da noi, sono statiche
//function Card(){
//   return(
//     <div className="box">
//           <img src="./public/gatto.jpg" alt="immagine" className="imm" />
//          <div>
//              <h2>Titolo</h2>
//             <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit.
//                 Alias, fuga quam nihil sint ex modi laborum voluptatibus quod laboriosam, repellat, 
//               temporibus numquam eius soluta tenetur eveniet molestias esse earum vel.</p>
//        </div>
//    </div>
//   )
//}


// La Card ora è dinamica
function Card({title, desc, imgURL, isVisited, children}){

   // Custom hook
   useCounterProva();
   
   return(
     <div className="box" style={{display : "flex" ,flexDirection: 'column'}}>
           <img src={imgURL} alt="immagine" className="imm" />
          <div style={{display : "flex",
                      flexDirection: 'column', 
                      maxWidth: "400px",
                      padding: "16px"}}>

              <h2>{title}</h2>
             <p>{desc}</p>
             {children}
             {isVisited ? <span><br></br>Adottato</span> : <span><br></br>Non Adottato</span>}
             {isVisited && <span> da una famiglia generosa</span>}
        </div>
    </div>
   )
}

export default Card;