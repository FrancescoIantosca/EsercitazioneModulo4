import './NavBar.css'

function NavBar() {
  const x = 15;

  const stile = {
    color: x < 10 ? "green" : "red"
  }

  return (
    <>
    <div id="box" className={`rounded ${x < 10 ? "ruota" : ""}`}>ciao</div>
    <ul>
        <li style={stile}><a href="">Ciao</a></li>
        <li><a href="">Ciao</a></li>
        <li><a href="">Ciao</a></li>
        <li><a href="">Ciao</a></li>
        <li><a href="">Ciao</a></li>
    </ul>
    </>
  )
}

export default NavBar