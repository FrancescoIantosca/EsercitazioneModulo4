import { useState, useEffect } from "react";

function Example() {
    const [count, setCount] = useState(0);

    //Definizione dell'effetto
    useEffect(() => {
        localStorage.setItem("count", count.toString()); //Local Storage
        document.title = `Conteggio =  ${count}`;
    }, [count]); // Dependency

    // Senza l'uso di useEffect, in questo modo si aggiorna anche il titolo del documento
    // non solo non gestiamo gli effetti collaterali, non è sincronizzato

    //const handleClick = () => {
    //    setCount(count + 1);
    //    document.title = `Conteggio =  ${count}`;
    //};

    return(
        <div>
            <p>
                Conteggio: {count}
            </p>
            <button onClick = {() => setCount(count + 1)}>
                Incrementa
            </button>
        </div>
    );

}
export default Example;