import { useState } from 'react'

function Form({addGatti}){

    const [formData, setFormData] = useState({
        title : "",
        desc : "",
        imgURL : "",
        isVisited : false
    })

    const handleSubmit = (e) => {
        e.preventDefault();
      const gatto =  {
    id : Math.random(),
    title : formData.title,
    desc : formData.desc,
    imgURL : formData.imgURL,
    isVisited : formData.isVisited, 
    };
        addGatti(gatto);
    }

    const handleInputChange = (e) => {
        const {name, value, type, checked} = e.target;
        const inputValue = type == "checkbox" ? checked : value;
        setFormData({
            ...formData,
            [name] : inputValue,
        });
    };

    return(
        <form onSubmit={handleSubmit}>

            <div style={{display: 'flex',
                        flexDirection: 'column',
                        gap: '10px', // Spazio tra gli elementi
                        border: '1px solid #ccc',
                        padding: '10px'}}>
                            
                <label>Nome Gatto</label>
                <input type="text" name="title" value={formData.title} onChange={handleInputChange}></input>

                <label>Descrizione</label>
                <textarea name="desc" value={formData.desc} onChange={handleInputChange}></textarea>

                <label>URL immagine</label>
                <input type="text" name="imgURL" value={formData.imgURL} onChange={handleInputChange}></input>

                <label>Adottato?</label>
                <input type="checkbox" name="isVisited" checked={formData.isVisited} onChange={handleInputChange}></input>

                <button type="submit">Aggiungi card</button>

            </div>
        </form>
    );
}

export default Form;