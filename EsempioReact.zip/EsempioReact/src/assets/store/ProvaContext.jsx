import { createContext } from "react";

export const ProvaContext = createContext({});